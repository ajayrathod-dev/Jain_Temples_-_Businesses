<?php
return [
    'pageTitle' => 'Jain Temples & Businesses',
    'welcomeMessage' => "Welcome to Maharashtra's Wonders",
    'searchPlaceholder' => "Search Temples..."
];
