<?php
return [
    'pageTitle' => 'जैन मंदिर और व्यवसाय',
    'welcomeMessage' => "महाराष्ट्र के चमत्कारों में आपका स्वागत है",
    'searchPlaceholder' => "मंदिर खोजें..."
];
